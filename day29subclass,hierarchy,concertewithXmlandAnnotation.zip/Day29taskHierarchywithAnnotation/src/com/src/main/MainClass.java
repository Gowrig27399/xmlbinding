package com.src.main;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.src.model.Student1;
import com.src.model.Student;
import com.src.model.Student2;


public class MainClass {

	public static void main(String[] args) {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
   
    SessionFactory factory = meta.getSessionFactoryBuilder().build();
    Session session = factory.openSession();
    Transaction t = session.beginTransaction();
Student e= new Student();
e.setName("gowri");
e.setAge(44);

Student1 s1=new Student1();
s1.setHours(45);
s1.setFees(2000.50);
s1.setAge(34);
s1.setName("siva");

Student2 s2=new Student2();
s2.setSubjet(5);
s2.setMark(200);
s2.setAge(45);
s2.setName("surya");


session.save(e);
session.save(s1);
session.save(s2);
     t.commit();
     System.out.println(" update inserted successfullly");
     session.close();
     factory.close();

}
}
