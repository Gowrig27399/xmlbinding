package com.src.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value="stu2")
public class Student2  extends Student{

	private int subjet;
	private int mark;
	
	
	public int getSubjet() {
		return subjet;
	}
	public void setSubjet(int subjet) {
		this.subjet = subjet;
	}
	public int getMark() {
		return mark;
	}
	public void setMark(int mark) {
		this.mark = mark;
	}
	
	
	
}
