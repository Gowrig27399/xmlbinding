package com.src.model;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


@Entity
@Table(name="edb")
@AttributeOverrides({
	
	@AttributeOverride(name="personId",column=@Column(name="personId")),
	@AttributeOverride(name="firstname",column=@Column(name="firstname")),
	@AttributeOverride(name="lastname",column=@Column(name="lastname"))
	
	
	
})

public class Employee extends Person {

	private int empid;
	private String depName;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getDepName() {
		return depName;
	}
	public void setDepName(String depName) {
		this.depName = depName;
	}
	
	
	
	
	
}
