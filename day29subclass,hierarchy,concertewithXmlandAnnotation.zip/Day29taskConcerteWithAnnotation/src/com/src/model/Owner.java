package com.src.model;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="odb")
@AttributeOverrides({
	
	@AttributeOverride(name="personId",column=@Column(name="personId")),
	@AttributeOverride(name="firstname",column=@Column(name="firstname")),
	@AttributeOverride(name="lastname",column=@Column(name="lastname"))
	
	
	
})
public class Owner extends Person {

	private int stocks;
	private int partnershipStake;
	public int getStocks() {
		return stocks;
	}
	public void setStocks(int stocks) {
		this.stocks = stocks;
	}
	public int getPartnershipStake() {
		return partnershipStake;
	}
	public void setPartnershipStake(int partnershipStake) {
		this.partnershipStake = partnershipStake;
	}
	
	
}
