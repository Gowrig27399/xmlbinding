package com.src.Main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.src.model.Employee;
import com.src.model.Owner;
import com.src.model.Person;


public class MainClass {

	public static void main(String[] args) {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
   
    SessionFactory factory = meta.getSessionFactoryBuilder().build();
    Session session = factory.openSession();
    Transaction t = session.beginTransaction();
Person p= new Person();

p.setFirstname("gowri");
p.setLastname("govindharaj");

Employee e=new Employee();
e.setDepartmentName("market");
e.setEmpid(33);
e.setFirstname("dhamu");
e.setLastname("rani");

Owner o=new Owner();
o.setStocks(300);
o.setPartnershipStake(299);
o.setFirstname("devi");
o.setLastname("govindharaj");

session.save(p);
session.save(e);
session.save(o);
     t.commit();
     System.out.println(" update inserted successfullly");
     session.close();
     factory.close();

}
}
