package com.src.main;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.src.model.Customer;

import com.src.model.Employee;



public class MainClass {

	public static void main(String[] args) {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
   
    SessionFactory factory = meta.getSessionFactoryBuilder().build();
    Session session = factory.openSession();
    Transaction t = session.beginTransaction();
    Employee e= new Employee();
    e.setEmpName("gowri");
    
   Customer c=new Customer();
   c.setcId(67);
   c.setCname("navai");
   c.setMobno(123456);
      c.setEmp(e);
      e.setCus(c);
  session.persist(e);
  
  Employee e1= new Employee();
  e1.setEmpName("devi");
  
 Customer c1=new Customer();
 c1.setcId(68);
 c1.setCname("rohini");
 c1.setMobno(123456344);
    c1.setEmp(e1);
    e1.setCus(c1);
session.persist(e1);
  


     t.commit();
     System.out.println(" update inserted successfullly");
     session.close();
     factory.close();

}
}
