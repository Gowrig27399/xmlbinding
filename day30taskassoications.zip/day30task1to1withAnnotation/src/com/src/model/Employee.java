package com.src.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="employee2")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
@PrimaryKeyJoinColumn
	private  int empId;
private String empName;
@OneToOne(targetEntity = Customer.class,cascade = CascadeType.ALL)
private Customer cus;//uniway association


public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public Customer getCus() {
	return cus;
}
public void setCus(Customer cus) {
	this.cus = cus;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", empName=" + empName + ", cus=" + cus + "]";
}


	
}
