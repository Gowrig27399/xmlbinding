package com.src.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

@Entity
@Table(name="quiz14")
public class Quiz {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private int queId;
	private String queValue;
	@ManyToMany(targetEntity= Answer.class,cascade= CascadeType.ALL)
	@JoinTable(name="queans",joinColumns = {@JoinColumn(name="queId")},inverseJoinColumns = {@JoinColumn(name="ansId")})
	
	private List<Answer> answers;
	
	
	
	
	public int getQueId() {
		return queId;
	}
	public void setQueId(int queId) {
		this.queId = queId;
	}
	public String getQueValue() {
		return queValue;
	}
	public void setQueValue(String queValue) {
		this.queValue = queValue;
	}
	public List<Answer> getAnswers() {
		return answers;
	}
	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}
	
	
}
