package com.src.main;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.src.model.Customer;

import com.src.model.Employee;



public class MainClass {

	public static void main(String[] args) {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
   
    SessionFactory factory = meta.getSessionFactoryBuilder().build();
    Session session = factory.openSession();
    Transaction t = session.beginTransaction();
    Employee e= new Employee();
    e.setEmpName("gowri");
    
    Customer a= new Customer();
      a.setHouseNo(101);    
      a.setCity("dgl");
      a.setPincode(624002);
      a.setState("tamilnadu");
      
      e.setAdd(a);
      a.setEmp(e);
  session.persist(e);
  


     t.commit();
     System.out.println(" update inserted successfullly");
     session.close();
     factory.close();

}
}
