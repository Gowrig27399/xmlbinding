package com.src.model;

public class Employee {
private  int empId;
private String empName;
private Customer add;//uniway association
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public Customer getAdd() {
	return add;
}
public void setAdd(Customer add) {
	this.add = add;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", empName=" + empName + ", add=" + add + "]";
}


	
}
