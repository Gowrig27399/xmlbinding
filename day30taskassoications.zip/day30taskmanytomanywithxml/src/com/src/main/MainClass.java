package com.src.main;



import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;


import com.src.model.Answer;

import com.src.model.Quiz;



public class MainClass {

	public static void main(String[] args) {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
   
    SessionFactory factory = meta.getSessionFactoryBuilder().build();
    Session session = factory.openSession();
    Transaction t = session.beginTransaction();
    Quiz  q=new Quiz();
    q.setQueValue("what is sun ?");
     
    
    Answer a=new Answer();
    a.setAnsDesc("it is a powerful");
    a.setPostedBy("gowri is great");
    Answer a1=new Answer();
    a1.setAnsDesc("it is a power light");
    a1.setPostedBy("dhana is good");
    
    ArrayList<Answer> al=new ArrayList();
    al.add(a);
    al.add(a1);
    
    q.setAnswers(al);
    //second qt
    Quiz  q1=new Quiz();
    q1.setQueValue("what is tree ?");
     
    
    Answer a2=new Answer();
    a2.setAnsDesc("it is a green clr");
    a2.setPostedBy("gowri is great");
    Answer a3=new Answer();
    a3.setAnsDesc("lot o useful");
    a3.setPostedBy("rohini is great");
    
    ArrayList<Answer> al1=new ArrayList();
    al1.add(a2);
    al1.add(a3);
    
    q1.setAnswers(al1);
    session.persist(q);
    session.persist(q1);
  


     t.commit();
     System.out.println(" update inserted successfullly");
     session.close();
     factory.close();

}
}
