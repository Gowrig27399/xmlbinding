package com.src.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.src.model.Customer;
import com.src.model.Employee;



public class MainClass {

	public static void main(String[] args) {
		
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
   
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();
        Transaction t = session.beginTransaction();
        
        Employee e = new Employee();
        e.setEmpName("gowrigovindharaj");
        
        Customer a = new Customer();
        a.setHouseNo(101);
        a.setCity("dindigul");
        a.setState("tamilnadu");
        a.setPinCode(624002);
        
        e.setAd(a);
        
        Employee e1 = new Employee();
        e1.setEmpName("rohinigovindhraj");
        
        e1.setAd(a);
        
        session.persist(e1);
        session.persist(e);
        
        t.commit();
        System.out.println("Data saved Successfully in database");
        session.close();
	    factory.close();
	}

}