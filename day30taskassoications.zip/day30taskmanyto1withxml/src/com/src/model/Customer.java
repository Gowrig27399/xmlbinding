package com.src.model;

public class Customer {

	private int addId;
	private int houseNo;
	private String city;
	private String state;
	private long pinCode;
	private Employee emp;
	
	@Override
	public String toString() {
		return "Address [addId=" + addId + ", houseNo=" + houseNo + ", city=" + city + ", state=" + state + ", pinCode="
				+ pinCode + ", emp=" + emp + "]";
	}
	
	public int getAddId() {
		return addId;
	}

	public void setAddId(int addId) {
		this.addId = addId;
	}
	
	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}
	
	public int getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getPinCode() {
		return pinCode;
	}
	public void setPinCode(long pinCode) {
		this.pinCode = pinCode;
	}
	
}