package com.src.model;


public class Employee {

	private int empId;
	private String empName;
	private Customer ad;	//Uniway Association
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Customer getAd() {
		return ad;
	}
	public void setAd(Customer ad) {
		this.ad = ad;
	}
	
}