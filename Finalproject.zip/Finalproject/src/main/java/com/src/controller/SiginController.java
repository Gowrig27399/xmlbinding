package com.src.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class SiginController {

	@RequestMapping("/signinpage")  
    public ModelAndView sigin() { 
	        return new ModelAndView("signinpage"); 
	}
}
