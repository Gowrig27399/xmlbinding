package com.src.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.src.model.CompetionHost;
import com.src.service.CompetionHostservice;

public class CompetionHostController {
	
	private static final Logger logger = Logger
			.getLogger(CompetionHostController.class);

	public CompetionHostController () {
		System.out.println("CompetionHostController()");
	}

	@Autowired
	private CompetionHostservice CompetionHostservice;

	@RequestMapping(value = "/")
	public ModelAndView listCompetionHost(ModelAndView model) throws IOException {
		List<CompetionHost> listCompetionHost = CompetionHostservice.getCompetionList();
		model.addObject("listCompetionHost",listCompetionHost);
		model.setViewName("home");
		return model;
	}

	@RequestMapping(value = "/newCompetionHost", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		CompetionHost CompetionHost = new CompetionHost();
		model.addObject("CompetionHost", CompetionHost);
		model.setViewName("CompetionHostForm");
		return model;
	}

	@RequestMapping(value = "/saveCompetionHost", method = RequestMethod.POST)
	public ModelAndView saveCompetionHost(@ModelAttribute CompetionHost CompetionHost) {
		if (CompetionHost.getCompetionHostId() == 0) { // if employee id is 0 then creating the
			// employee other updating the employee
			CompetionHostservice.AddCompetionHost(CompetionHost);
		} else {
			CompetionHostservice.updateCompetionHost(CompetionHost);
		}
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/deleteCompetionHost", method = RequestMethod.GET)
	public ModelAndView deleteCompetionHost(HttpServletRequest request) {
		int CompetionHostId = Integer.parseInt(request.getParameter("CompetionHostId"));
		CompetionHostservice.deleteCompetionHost(CompetionHostId);
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/editCompetionHost", method = RequestMethod.GET)
	public ModelAndView editCompetionHost(HttpServletRequest request) {
		int CompetionHostId = Integer.parseInt(request.getParameter("CompetionHostId"));
		CompetionHost CompetionHost =CompetionHostservice .getCompetionHost(CompetionHostId);
		ModelAndView model = new ModelAndView("CompetionHostForm");
		model.addObject("CompetionHost", CompetionHost);

		return model;
	}

}
