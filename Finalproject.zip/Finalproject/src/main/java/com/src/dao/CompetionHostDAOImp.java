package com.src.dao;

import java.util.List;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.src.model.CompetionHost;


@Repository
public class CompetionHostDAOImp implements CompetionHostDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void AddCompetionHost(CompetionHost CompetionHost) {
		sessionFactory.getCurrentSession().saveOrUpdate(CompetionHost);
		
	}

	@SuppressWarnings("unchecked")
	public List<CompetionHost> getCompetionList() {
		return sessionFactory.getCurrentSession().createQuery("from CompetionHost")
				.list();
	}

	@Override
	public void deleteCompetionHost(Integer CompetionHostId) {
		CompetionHost CompetionHost = (CompetionHost) sessionFactory.getCurrentSession().load(
				CompetionHost.class, CompetionHostId);
		if (null != CompetionHost) {
			this.sessionFactory.getCurrentSession().delete(CompetionHost);
		}
		
	}

	@Override
	public CompetionHost getCompetionHost(int CompetionHostId) {
		return (CompetionHost) sessionFactory.getCurrentSession().get(
				CompetionHost.class, CompetionHostId);
	}

	@Override
	public CompetionHost updateCompetionHost(CompetionHost CompetionHost) {
		sessionFactory.getCurrentSession().update(CompetionHost);
		return CompetionHost;
	
	}

	
	
	
	

}
