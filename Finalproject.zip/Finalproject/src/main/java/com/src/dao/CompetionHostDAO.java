package com.src.dao;

import java.util.List;

import com.src.model.CompetionHost;

public interface CompetionHostDAO {
	
	public void AddCompetionHost(CompetionHost CompetionHost);

	public List<CompetionHost> getCompetionList();

	public void deleteCompetionHost(Integer CompetionHostId);

	public CompetionHost getCompetionHost(int CompetionHostId);

	public CompetionHost updateCompetionHost(CompetionHost CompetionHost);

}