package com.src.service;

import java.util.List;

import com.src.model.CompetionHost;

public interface CompetionHostservice {
	
	public void AddCompetionHost(CompetionHost CompetionHost);

	public List<CompetionHost> getCompetionList();

	public void deleteCompetionHost(Integer CompetionHostId);

	public CompetionHost getCompetionHost(int CompetionHostId);

	public CompetionHost updateCompetionHost(CompetionHost CompetionHost);

}
