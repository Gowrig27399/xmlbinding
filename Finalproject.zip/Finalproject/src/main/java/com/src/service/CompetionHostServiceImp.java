package com.src.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.src.controller.CompetionHostController;
import com.src.dao.CompetionHostDAO ;
import com.src.model.CompetionHost;

public class CompetionHostServiceImp implements CompetionHostservice{
	
	@Autowired
	private CompetionHostDAO CompetionHostDAO;

	@Override
	@Transactional
	public void AddCompetionHost(CompetionHost CompetionHost) {
		CompetionHostDAO.AddCompetionHost(CompetionHost);
		
	}

	@Override
	@Transactional
	public List<CompetionHost> getCompetionList() {
		return CompetionHostDAO.getCompetionList();
	}

	@Override
	@Transactional
	public void deleteCompetionHost(Integer CompetionHostId) {
		CompetionHostDAO.deleteCompetionHost(CompetionHostId);
		
	}

	@Override
	public CompetionHost getCompetionHost(int CompetionHostId) {
		return CompetionHostDAO.getCompetionHost(CompetionHostId);
	}

	@Override
	public CompetionHost updateCompetionHost(CompetionHost CompetionHost) {
		// TODO Auto-generated method stub
		return CompetionHostDAO.updateCompetionHost(CompetionHost);
	}
	
	public void setCompetionHostDAO(CompetionHostDAO competionHostDAO) {
		this.CompetionHostDAO = competionHostDAO;
	}
	
	

	
	
}