package com.src.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "competionhost")

public class CompetionHost implements Serializable {
	
	private static final long serialVersionUID = -3465813074586302847L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int CompetionHostId;
   
    @Column
	private String competionName;
	
    @Column
	private String comStartdate;
    
    @Column
	private String comEnddate;
    
    @Column
	private String comMinparticipant;
    
    @Column
	private String comMaxparticipant;
    
    @Column
	private double amount;
    
    @Column
	private String image;
	
	

	public int getCompetionHostId() {
		return CompetionHostId;
	}

	public void setCompetionHostId(int competionHostId) {
		CompetionHostId = competionHostId;
	}

	public String getCompetionName() {
		return competionName;
	}

	public void setCompetionName(String competionName) {
		this.competionName = competionName;
	}

	public String getComStartdate() {
		return comStartdate;
	}

	public void setComStartdate(String comStartdate) {
		this.comStartdate = comStartdate;
	}

	public String getComEnddate() {
		return comEnddate;
	}

	public void setComEnddate(String comEnddate) {
		this.comEnddate = comEnddate;
	}

	public String getComMinparticipant() {
		return comMinparticipant;
	}

	public void setComMinparticipant(String comMinparticipant) {
		this.comMinparticipant = comMinparticipant;
	}

	public String getComMaxparticipant() {
		return comMaxparticipant;
	}

	public void setComMaxparticipant(String comMaxparticipant) {
		this.comMaxparticipant = comMaxparticipant;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	
	
}
