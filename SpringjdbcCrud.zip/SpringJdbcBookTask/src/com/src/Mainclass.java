package com.src;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.BookDao;
import com.model.Book;



public class Mainclass {

	public static void main(String[] args) {
	
			ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
			
			BookDao bdao=(BookDao) context.getBean("bookdao1");
			
			int status=bdao.saveBook(new Book(20,"java spot",400));
					
			if(status>0)
			{
				System.out.println("values got inserted");
			}
			else
			{
				System.out.println("unable to insert values");
			}

		 status=bdao.deleteBook(new Book(25,"",0));
			
			if(status>0)
			{
				System.out.println("values got delete");
			}
			else
			{
				System.out.println("unable to delete");
		
			}
			boolean status1=bdao.saveBookbyPs(new Book(2,"my god",3000));
			
			if(!status1)
				System.out.println("values inserted by prepared statement");
			else
				System.out.println("unsucuessfil insertion by preparedstatement");
			
			
	boolean status2=((BookDao) bdao).UpdateBook(new Book(2,"nice",0));
			if(!status2)
				System.out.println("updated");
			else
				System.out.println("not updated");
			
			List<Book> l=bdao.getBooks();
			 for(Book b:l)
			 {
				 System.out.println(b);
			 }
	}

}

