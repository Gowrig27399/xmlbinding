package com.dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.model.Book;


public class BookDao {
	private JdbcTemplate jdbctemp;

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public int saveBook(Book b)
	{
		String sql="insert into book values("+b.getBid()+ ",'" +b.getBname()+ "'," +b.getBprice()+")";
				
		return jdbctemp.update(sql); 
	}
	public int deleteBook(Book b)
	{
		String sql="delete from Book where bid="+b.getBid();					
		return jdbctemp.update(sql); 
	}
	
	

	public Boolean saveBookbyPs(Book b)
	{

		String sql="insert into book values(?,?,?)";
		return jdbctemp.execute(sql,new PreparedStatementCallback<Boolean>()
				{

					@Override
					public Boolean doInPreparedStatement(PreparedStatement ps)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
					
			
			
			ps.setInt(1,b.getBid());
			ps.setString(2,b.getBname());
			ps.setDouble(3, b.getBprice());
			return ps.execute();
			
			
					}		
				});
				
}

public Boolean UpdateBook(Book b)
{
	String sql = "UPDATE book "
            + "SET bid = ? "
            + "WHERE bname = ?";
	return jdbctemp.execute(sql,new PreparedStatementCallback<Boolean>()
			{

				@Override
				public Boolean doInPreparedStatement(PreparedStatement ps)
						throws SQLException, DataAccessException {
					// TODO Auto-generated method stub
				
		
		
		ps.setInt(1,b.getBid());
		ps.setString(2,b.getBname());
		//ps.setDouble(3, e.getSalary());
		return ps.execute();
		
		
				}		
			});
			
}

	public List<Book> getBooks()
	{
		
		String sql="select * from book;";
		ResultSetExtractor rse=new ResultSetExtractor() {

			@Override
			public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<Book> list=new ArrayList<>();
				while(rs.next())
				{
					list.add(new Book(rs.getInt(1), rs.getString(2),rs.getDouble(3)));
				}
				return list;
			}
			
		};
		return (List<Book>) jdbctemp.query(sql, rse);
		
	}

}
